@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "OPORA_PACKAGE_ROOT=%~dp0."
set "OPORA_EXE=%OPORA_PACKAGE_ROOT%\Opora-App\Opora-win32-x64\Opora.exe"
if not exist "%OPORA_EXE%" set "OPORA_EXE=%OPORA_PACKAGE_ROOT%\Opora.exe"
if not exist "%OPORA_EXE%" (
 echo Put the complete update ZIP beside START-OPORA.cmd or Opora.exe.
 pause
 exit /b 1
)
set "ELECTRON_RUN_AS_NODE=1"
"%OPORA_EXE%" "%OPORA_PACKAGE_ROOT%\opora-update\new-app.asar\desktop\migrate.cjs" "%OPORA_PACKAGE_ROOT%" --repair
if errorlevel 1 pause
