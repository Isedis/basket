@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "OPORA_PACKAGE_ROOT=%~dp0"
cd /d "%TEMP%"
powershell.exe -NoLogo -NoProfile -Command "& ([scriptblock]::Create([IO.File]::ReadAllText((Join-Path $env:OPORA_PACKAGE_ROOT 'light-update.ps1'))))"
if errorlevel 1 pause
