@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "OPORA_PACKAGE_ROOT=%~dp0"
cd /d "%TEMP%"
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%OPORA_PACKAGE_ROOT%light-update.ps1"
if errorlevel 1 pause
